from module import main_handeler
while True:
    main_handeler.main_run()